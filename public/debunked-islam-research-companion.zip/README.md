# DEBUNKED: ISLAM — Chapter 12 research companion

Author: Lovepreet Singh. Prepared 29 October 2026. This companion contains a reproducible count and exact fraction calculations discussed in Chapter 12. It is not the complete book.

## Contents

- check_chapter12_counts.py: Python 3, standard library only.
- chapter-12-day-count-locations.csv: all 475 selected locations and their assigned categories. The companion list contains locations and classifications, not the full source dataset or its Arabic annotations.
- CHAPTER-12-COUNTS-AND-ARITHMETIC.json: calculated results, assumptions and source hash.
- SHA256.json: hashes of the other companion files.

## Obtain the unchanged input

The data are the mustafa0x fork of the Quranic Arabic Corpus, revision 8f38b39. The original project and its data have their own attribution and licensing terms; those terms are not replaced by this companion.

Project: https://github.com/mustafa0x/quran-morphology/tree/8f38b39

Pinned file: https://raw.githubusercontent.com/mustafa0x/quran-morphology/8f38b39/quran-morphology.txt

Save the downloaded file without editing it. Expected SHA-256:
742bfac59941b2cb09736d5b7aae694af50792261fb8450cbf6afafcc340645f

The source data are not bundled here. The script checks their hash before counting. A different hash is an error to investigate, not permission to modify the data until the result matches.

## Run

With Python 3 installed, run in this folder:

python check_chapter12_counts.py --source "PATH/TO/quran-morphology.txt"

The script writes the CSV and JSON outputs next to itself. It groups segments by word location, selects the day lemma, recognises both relevant plural labels, and classifies plural, dual, compound, possessive and remaining singular forms. At location 3:24:8, the final number identifies the eighth word of verse 3:24.

## Expected result and limits

The categories contain 365 remaining singular forms, 10 possessive singular forms, 70 compounds, 27 plurals and 3 duals: 475 selected locations. Including possessive singulars with the remaining singular group gives 375. These are results for this pinned annotation and these rules; they are not an independent reannotation of Arabic or a probability of divine authorship.

Exact fraction arithmetic checks a hypothetical distributable estate of 216,000 rupees, with a wife, mother, father and three daughters, no sons, and these heirs only. The nominal shares sum to 9/8. Both the proportional adjustment and the specified priority approach then sum to one whole estate, with different allocations. This reproduces the chapter's example, not individual estate advice.

The public companion script uses the same counting and arithmetic as the research script. Its CSV omits the Arabic word, segment and morphology columns to keep the distributed reference list focused on locations and classifications. Consult the pinned input for the original annotations.
