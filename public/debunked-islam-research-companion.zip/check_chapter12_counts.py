"""Reproduce Chapter 12's counts and fraction examples from a pinned source.

No source text is changed. Classification follows grammatical features, not a
search for a desired total. The CSV records every included or excluded location.
Run with Python 3; standard library only.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
import csv
import argparse
import hashlib
import json

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', type=Path, required=True, help='Path to the unmodified pinned quran-morphology.txt download')
source = parser.parse_args().source
raw = source.read_bytes()
digest = hashlib.sha256(raw).hexdigest()
expected_hash = '742bfac59941b2cb09736d5b7aae694af50792261fb8450cbf6afafcc340645f'
if digest != expected_hash:
    raise ValueError('Source differs from the recorded pinned download')
words = defaultdict(list)
for line in raw.decode('utf-8-sig').splitlines():
    if not line or line.startswith('#'):
        continue
    location, form, part_of_speech, features = line.split('\t')
    word_location = tuple(map(int, location.split(':')[:3]))
    words[word_location].append({
        'location': location, 'form': form, 'pos': part_of_speech,
        'features': features.split('|')})

rows = []
for location, segments in words.items():
    matches = [s for s in segments if 'LEM:يَوْم' in s['features']]
    if not matches:
        continue
    assert len(matches) == 1
    segment = matches[0]
    tags = segment['features']
    if any(t in tags for t in ('MP', 'FP', 'P')):
        category = 'plural'
    elif any(t in tags for t in ('MD', 'FD', 'D')):
        category = 'dual'
    elif any('LEM:إِذ' in s['features'] for s in segments):
        category = 'compound_that_day'
    elif any('PRON' in s['features'] and 'SUFF' in s['features'] for s in segments):
        category = 'possessive_singular'
    else:
        category = 'remaining_singular'
    rows.append({
        'location': ':'.join(map(str, location)),
        'word': ''.join(s['form'] for s in segments),
        'day_segment': segment['form'], 'category': category,
        'features': '|'.join(tags)})

counts = dict(Counter(r['category'] for r in rows))
expected = {'remaining_singular': 365, 'plural': 27, 'dual': 3,
            'compound_that_day': 70, 'possessive_singular': 10}
assert counts == expected, counts
assert len(rows) == 475
assert len(words) == 77429
assert next(r for r in rows if r['location'] == '3:24:8')['category'] == 'plural'
with (root / 'chapter-12-day-count-locations.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=['location', 'category'], extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)

base = {'wife': Fraction(1, 8), 'father': Fraction(1, 6),
        'mother': Fraction(1, 6), 'daughters_collectively': Fraction(2, 3)}
total = sum(base.values())
awl = {k: v / total for k, v in base.items()}
priority = dict(base)
priority['daughters_collectively'] = 1 - base['wife'] - base['father'] - base['mother']
assert total == Fraction(9, 8)
assert sum(awl.values()) == sum(priority.values()) == 1
estate = 216000
nominal_money = {k: estate * v for k, v in base.items()}
awl_money = {k: estate * v for k, v in awl.items()}
priority_money = {k: estate * v for k, v in priority.items()}
assert all(v.denominator == 1 for values in (nominal_money, awl_money, priority_money) for v in values.values())
report = {
    'source_url': 'https://raw.githubusercontent.com/mustafa0x/quran-morphology/8f38b39/quran-morphology.txt',
    'source_sha256': digest, 'source_bytes': len(raw), 'word_locations': len(words),
    'selected_lemma': 'يَوْم', 'total_selected_segments': len(rows),
    'counts': counts, 'noncompound_singular_including_possessives': 375,
    'note': 'MP and FP both indicate plural in this file; 3:24:8 is FP. Excluding it accidentally would give 366, not a competing valid singular count.',
    'inheritance': {
        'family': 'wife, father, mother, three daughters, no sons; these are the only heirs in this illustrative case',
        'distributable_estate': estate,
        'nominal': {k: str(v) for k, v in base.items()}, 'nominal_total': str(total),
        'awl': {k: str(v) for k, v in awl.items()},
        'priority_rule': {k: str(v) for k, v in priority.items()},
        'nominal_money': {k: int(v) for k, v in nominal_money.items()},
        'awl_money': {k: int(v) for k, v in awl_money.items()},
        'priority_money': {k: int(v) for k, v in priority_money.items()},
    },
    'scope': 'Reproduction of specified token rules and exact arithmetic; not independent Arabic annotation, historical provenance, legal advice, or a probability of divine authorship.',
    'pass': True,
}
(root / 'CHAPTER-12-COUNTS-AND-ARITHMETIC.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
